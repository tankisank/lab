# apple train > 2023-05-11 3:38pm
https://universe.roboflow.com/ju-ooq5z/apple-train

Provided by a Roboflow user
License: CC BY 4.0

